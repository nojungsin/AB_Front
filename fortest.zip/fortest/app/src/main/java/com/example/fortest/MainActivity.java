package com.example.fortest;

import android.os.Bundle;
import android.view.View;
import android.widget.CalendarView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private CalendarView calendarView;
    private TextView monthlyInDay, monthlyInnum, monthlyOutDay, monthlyOutnum, weeklyInDay, weeklyInnum, weeklyOutDay, weeklyOutnum, dailyInDay, dailyInTime, dailyInnum, dailyOutDay, dailyOutTime, dailyOutnum;

    private LinearLayout monthInItems, monthOutItems, weekInItems, weekOutItems, dayInItems, dayOutItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        calendarView = findViewById(R.id.calendarView);

        // 캘린더 날짜 클릭 이벤트 처리
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            // 선택된 날짜 가져오기
            Calendar selectedDate = Calendar.getInstance();
            selectedDate.set(year, month, dayOfMonth);

            // 날짜 형식 지정
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

            // 데이터 업데이트 (임시 데이터 사용)
            updateData(year,month,dayOfMonth);
        });
    }

    // 날짜별 입출력 데이터 업데이트
    private void updateData(int year, int month, int day) {
        //날짜 기반으로 월간/주간/일간 입출금 데이터 가져오기
        int monthlyOutS = 1000;
        int monthlyInS = 2000;
        int weeklyOutS = 3000;
        int weeklyInS = 4000;
        int dailyOutS = 5000;
        int dailyInS = 6000;
        String dailylatestintime = "12:27";
        String dailylatestouttime = "15:30";

        //세팅
        //날짜/시간 받기
        monthlyInDay = findViewById(R.id.select_month_in);
        monthlyOutDay = findViewById(R.id.select_month_out);
        weeklyInDay = findViewById(R.id.select_week_in);
        weeklyOutDay = findViewById(R.id.select_week_out);
        dailyInDay = findViewById(R.id.select_day_in);
        dailyOutDay = findViewById(R.id.select_day_out);
        dailyInTime = findViewById(R.id.select_day_intime);
        dailyOutTime = findViewById(R.id.select_day_outtime);

        //돈받기
        monthlyOutnum = findViewById(R.id.monthly_out_num);
        monthlyInnum = findViewById(R.id.monthly_in_num);
        weeklyOutnum = findViewById(R.id.weekly_out_num);
        weeklyInnum = findViewById(R.id.weekly_in_num);
        dailyOutnum = findViewById(R.id.daily_out_num);
        dailyInnum = findViewById(R.id.daily_in_num);

        //레이아웃
        monthInItems = findViewById(R.id.monthly_initems);
        monthInItems.setVisibility(View.VISIBLE);
        monthOutItems = findViewById(R.id.monthly_outitems);
        monthOutItems.setVisibility(View.VISIBLE);
        weekInItems = findViewById(R.id.weekly_initems);
        weekInItems.setVisibility(View.VISIBLE);
        weekOutItems = findViewById(R.id.weekly_outitems);
        weekOutItems.setVisibility(View.VISIBLE);
        dayInItems = findViewById(R.id.daily_initems);
        dayInItems.setVisibility(View.VISIBLE);
        dayOutItems = findViewById(R.id.daily_outitems);
        dayOutItems.setVisibility(View.VISIBLE);

        //월간 수입 출력
        monthlyInDay.setText(year+"년 "+month+"월 수입");
        monthlyInnum.setText(monthlyInS+"원");
        //월간 지출 출력
        monthlyOutDay.setText(year+"년 "+month+"월 지출");
        monthlyOutnum.setText(monthlyOutS+"원");

        //주간 수입 출력
        weeklyInDay.setText(year+"년 "+month+"월 "+day+"일 주간 수입");
        weeklyInnum.setText(weeklyInS+"원");
        //주간 지출 출력
        weeklyOutDay.setText(year+"년 "+month+"월 "+day+"일 주간 지출");
        weeklyOutnum.setText(weeklyOutS+"원");

        //당일 지출 출력(최종 업데이트 시간 출력)
        //스크롤뷰로 바꿔야함...
        dailyOutDay.setText(year+"/"+month+"/"+day);
        dailyOutnum.setText(dailyOutS+"원");
        dailyOutTime.setText(dailylatestouttime);

        //당일 수입 출력(최종 업데이트 시간 출력)
        dailyInDay.setText(year+"/"+month+"/"+day);
        dailyInnum.setText(dailyInS+"원");
        dailyInTime.setText(dailylatestintime);
    }
}
